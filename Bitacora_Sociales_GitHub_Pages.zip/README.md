# Bitácora de Sociales - GitHub Pages

Sitio oficial 2026 - Juan G. Cañón Torres - I.E. Antonio Nariño Mosquera

## Cómo publicar gratis e ilimitado

1. Crea cuenta en github.com
2. Crea repositorio nuevo: `bitacoradesocialesjt.github.io` (exacto, con tu usuario)
3. Sube todos los archivos de esta carpeta (index.html + carpeta assets)
4. Ve a Settings > Pages > Deploy from main branch
5. Tu web quedará en https://bitacoradesocialesjt.github.io

Sin límites de páginas, fotos ni visitas. Gratis para siempre.

## Contenido
- 9 secciones reales basadas en PDF oficial
- Sin palabra museo
- Fundamentación profunda 5 autores
- Evidencias reales: cartas trincheras, avatares candidato ideal, máscaras guerra fría, inventos
- Logos completos rectangulares

Fuente: Bitácora de Sociales 2026
